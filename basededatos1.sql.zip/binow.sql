-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: binow_out
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `D_CAMPOS`
--

DROP TABLE IF EXISTS `D_CAMPOS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `D_CAMPOS` (
  `nombre_jd` varchar(30) NOT NULL,
  `tipo_jd` varchar(30) NOT NULL,
  `tabla_nueva` varchar(30) NOT NULL,
  `tabla_jd` varchar(30) NOT NULL,
  `descripcion_ascii` varchar(60) NOT NULL,
  `descripcion_humana` varchar(60) NOT NULL,
  `id_global` varchar(60) NOT NULL,
  `tipo_js` varchar(30) NOT NULL,
  `oculto_js` int(11) NOT NULL,
  `tipo_mysql` varchar(30) NOT NULL,
  `tipo_conversion` varchar(30) NOT NULL,
  `conversion_comentario` tinytext NOT NULL,
  `eliminado` tinyint(4) NOT NULL DEFAULT '0',
  `eliminado_comentario` tinytext NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1487 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D_CAMPOS`
--

LOCK TABLES `D_CAMPOS` WRITE;
/*!40000 ALTER TABLE `D_CAMPOS` DISABLE KEYS */;
INSERT INTO `D_CAMPOS` VALUES ('birth_date','varchar(5)','D_RESUMEN_DATOS','D_empleados','birth_date','Fecha Nacimiento','D_RESUMEN_DATOS_birth_date','fecha',0,'otro','','',0,'',2),('first_name','varchar(30)','D_RESUMEN_DATOS','D_empleados','first_name','Nombre','D_RESUMEN_DATOS_first_name','codigo',0,'texto_varchar','','',0,'',3),('gender','varchar(2)','D_RESUMEN_DATOS','D_empleados','gender','Genero','D_RESUMEN_DATOS_gender','codigo',0,'texto_varchar','','',0,'',4),('hire_date','varchar(3)','D_RESUMEN_DATOS','D_empleados','hire_date','Fecha Contratado','D_RESUMEN_DATOS_hire_date','codigo',0,'texto_varchar','','',0,'',5),('salary','varchar(30)','D_RESUMEN_DATOS','D_empleados','salary','Salario','D_RESUMEN_DATOS_salary','moneda',0,'numero','','',0,'',6),('from_date','varchar(12)','D_RESUMEN_DATOS','D_empleados','from_date','Fecha desde','D_RESUMEN_DATOS_from_date','fecha',0,'otro','','',0,'',7),('to_date','varchar(3)','D_RESUMEN_DATOS','D_empleados','to_date','Fecha hasta','D_RESUMEN_DATOS_to_date','fecha',0,'otro','','',0,'',8),('emp_no','varchar(30)','D_RESUMEN_DATOS','D_empleados','emp_no','Cod.Empleado','D_RESUMEN_DATOS_emp_no','codigo',0,'numero','','',0,'',1486),('title','varchar(30)','D_RESUMEN_DATOS','D_empleados','title','Cargo','D_RESUMEN_DATOS_title','json',0,'texto_varchar','','',0,'',9),('from_date','varchar(3)','D_RESUMEN_DATOS','D_empleados','from_date','Cargo D Fecha','D_RESUMEN_DATOS_t_from_date','fecha',0,'otro','','',0,'',10),('t_to_date','varchar(30)','D_RESUMEN_DATOS','D_empleados','t_to_date','Cargo H Fecha','D_RESUMEN_DATOS_t_to_date','fecha',0,'numero','','',0,'',11);
/*!40000 ALTER TABLE `D_CAMPOS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D_RESUMEN_DATOS`
--

DROP TABLE IF EXISTS `D_RESUMEN_DATOS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `D_RESUMEN_DATOS` (
  `emp_no` int(11) NOT NULL,
  `birth_date` date NOT NULL,
  `first_name` varchar(14) NOT NULL,
  `last_name` varchar(16) NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `hire_date` date NOT NULL,
  `salary` int(11) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `t_from_date` date DEFAULT NULL,
  `t_to_date` date DEFAULT NULL,
  KEY `emp_no` (`emp_no`),
  KEY `title` (`title`),
  KEY `gender` (`gender`),
  KEY `salary` (`salary`),
  KEY `hire_date` (`hire_date`),
  KEY `from_date` (`from_date`),
  KEY `from_date_2` (`from_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D_RESUMEN_DATOS`
--

LOCK TABLES `D_RESUMEN_DATOS` WRITE;
/*!40000 ALTER TABLE `D_RESUMEN_DATOS` DISABLE KEYS */;
/*!40000 ALTER TABLE `D_RESUMEN_DATOS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `D_SCRIPTS`
--

DROP TABLE IF EXISTS `D_SCRIPTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `D_SCRIPTS` (
  `id_script` int(11) NOT NULL AUTO_INCREMENT,
  `nombretabla_jd` varchar(99) COLLATE utf8_spanish_ci NOT NULL,
  `nombrescript` varchar(99) COLLATE utf8_spanish_ci NOT NULL,
  `estado` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_script`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `D_SCRIPTS`
--

LOCK TABLES `D_SCRIPTS` WRITE;
/*!40000 ALTER TABLE `D_SCRIPTS` DISABLE KEYS */;
INSERT INTO `D_SCRIPTS` VALUES (2,'empleados','carga_empleados_completa.php',1);
/*!40000 ALTER TABLE `D_SCRIPTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ag_frescuratablas`
--

DROP TABLE IF EXISTS `ag_frescuratablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ag_frescuratablas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tabla` varchar(200) NOT NULL,
  `ultima_actualizacion` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ag_frescuratablas`
--

LOCK TABLES `ag_frescuratablas` WRITE;
/*!40000 ALTER TABLE `ag_frescuratablas` DISABLE KEYS */;
INSERT INTO `ag_frescuratablas` VALUES (2,'D_RESUMEN_DATOS','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `ag_frescuratablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allowdisallows`
--

DROP TABLE IF EXISTS `allowdisallows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowdisallows` (
  `id_allowdisallow` int(20) NOT NULL AUTO_INCREMENT,
  `path` tinytext NOT NULL,
  `way` enum('a','d') NOT NULL,
  `id_profile` int(11) NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_allowdisallow`)
) ENGINE=MyISAM AUTO_INCREMENT=668 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowdisallows`
--

LOCK TABLES `allowdisallows` WRITE;
/*!40000 ALTER TABLE `allowdisallows` DISABLE KEYS */;
INSERT INTO `allowdisallows` VALUES (187,'modreporting_avanzado','a',14,0),(251,'modgrupos/','a',14,0),(258,'modreporting/','a',14,0),(261,'modusuarios/','a',14,0),(264,'ventanas_administracion','a',14,0),(267,'modprofile/','a',14,0),(288,'modparametros/','a',14,0),(317,'modreporting/compartir_listados','a',14,0),(532,'modconfig/','a',14,0),(667,'modreporting/compartir_listados','d',86,0),(666,'modusuarios/','d',86,0),(664,'modprofile/','d',86,0),(663,'modgrupos/','d',86,0),(660,'modusuarios/','a',86,1),(661,'ventanas_administracion','a',86,0),(659,'modreporting_avanzado','a',86,0),(658,'modreporting/compartir_listados','a',86,1),(657,'modreporting/','a',86,0),(656,'modprofile/','a',86,1),(655,'modparametros/','a',86,0),(654,'modgrupos/','a',86,1),(653,'modconfig/','a',86,0);
/*!40000 ALTER TABLE `allowdisallows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arbol_permisos`
--

DROP TABLE IF EXISTS `arbol_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arbol_permisos` (
  `id_nodo` int(11) NOT NULL AUTO_INCREMENT,
  `id_padre` int(11) NOT NULL DEFAULT '0',
  `tipo` int(11) NOT NULL DEFAULT '0',
  `dato` tinytext NOT NULL,
  `condicion_dato1` varchar(200) NOT NULL,
  `condicion_dato2` varchar(200) NOT NULL,
  `condicion_operador` varchar(12) NOT NULL,
  `condicion1_esmacro` int(11) NOT NULL DEFAULT '0',
  `condicion2_esmacro` int(11) NOT NULL DEFAULT '0',
  `condicion_param1` varchar(200) NOT NULL,
  `condicion_param2` varchar(200) NOT NULL,
  PRIMARY KEY (`id_nodo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arbol_permisos`
--

LOCK TABLES `arbol_permisos` WRITE;
/*!40000 ALTER TABLE `arbol_permisos` DISABLE KEYS */;
INSERT INTO `arbol_permisos` VALUES (1,0,1,'and','','','',0,0,'','');
/*!40000 ALTER TABLE `arbol_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_logs`
--

DROP TABLE IF EXISTS `cap_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cap_logs` (
  `id_cap_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_cap` tinytext NOT NULL,
  `date_cap` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `event_cap` tinytext NOT NULL,
  `inf_cap` tinytext NOT NULL,
  PRIMARY KEY (`id_cap_log`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_logs`
--

LOCK TABLES `cap_logs` WRITE;
/*!40000 ALTER TABLE `cap_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `condiciones_macros`
--

DROP TABLE IF EXISTS `condiciones_macros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `condiciones_macros` (
  `id_condicion` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `phpname` varchar(99) NOT NULL,
  `tabla_referente` varchar(99) NOT NULL,
  `area` varchar(30) NOT NULL,
  `D_RESUMEN_DATOS` varchar(100) NOT NULL,
  PRIMARY KEY (`id_condicion`),
  KEY `descripcion` (`descripcion`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `condiciones_macros`
--

LOCK TABLES `condiciones_macros` WRITE;
/*!40000 ALTER TABLE `condiciones_macros` DISABLE KEYS */;
INSERT INTO `condiciones_macros` VALUES (48,'nº de empleado','','','','emp_no'),(49,'fecha nacimiento','','','','birth_date'),(50,'nombre','','','','first_name	'),(51,'apellido','','','','last_name'),(52,'Sexo','','','','gender'),(53,'fecha contrato','','','','hire_date'),(54,'salario','','','','salary'),(55,'fecha desde','','','','from_date'),(56,'fecha hasta','','','','to_date'),(57,'puesto','','','','title'),(58,'fecha desde t.','','','','t_from_date'),(59,'fecha hasta t.','','','','t_to_date');
/*!40000 ALTER TABLE `condiciones_macros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id_contact` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `region_mapa` int(11) NOT NULL DEFAULT '0',
  `id_contact_other` tinytext NOT NULL,
  `contact_name` tinytext CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `contact_code` varchar(30) NOT NULL,
  `priority` varchar(10) NOT NULL,
  `contact_unknown` int(11) NOT NULL DEFAULT '0',
  `eliminado` tinyint(4) NOT NULL,
  `esArgentino` int(11) NOT NULL DEFAULT '0',
  `old_code` varchar(50) NOT NULL,
  PRIMARY KEY (`id_contact`),
  KEY `contact_code` (`contact_code`),
  KEY `eliminado` (`eliminado`)
) ENGINE=MyISAM AUTO_INCREMENT=89122 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,1,'1','Desconocido','124','1',1,0,0,'124');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `describir_permiso`
--

DROP TABLE IF EXISTS `describir_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `describir_permiso` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `permiso` varchar(100) CHARACTER SET latin1 NOT NULL,
  `descripcion` varchar(400) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `describir_permiso`
--

LOCK TABLES `describir_permiso` WRITE;
/*!40000 ALTER TABLE `describir_permiso` DISABLE KEYS */;
INSERT INTO `describir_permiso` VALUES (3,' autoentrar_listareportes','Al entrar en la aplicaciÃ³n si tiene este permiso entra directamente en el canal de reporting'),(19,'modcanales/','Permiso para poder acceder al mantenimiento de canales'),(31,'modchannels/','Permiso para acceder al mantenimiento de channels'),(32,'modconfig/','Permiso para poder acceder al mantenimiento de parÃ¡metros de la aplicaciÃ³n'),(37,'modgrupos/','Permiso para poder acceder al mantenimiento de grupos'),(55,'modinformes/','Permiso para acceder al mantenimiento de informes'),(57,'modlistados/','Permiso para acceder al mantenimiento de listados'),(58,'modlistados/area/delegacion','Permiso para ver los listados correspondientes al Ã¡rea delegaciÃ³n'),(59,'modlistados/area/logistica','Permiso para ver los listados correspondientes al Ã¡rea logÃ­stica'),(60,'modlistados/area/todas','Permiso para ver los listados de todas las Ã¡reas'),(65,'modpanel/','Permiso para acceder al panel del usuario'),(68,'modparametros/','Permite acceder al mantenimiento de parÃ¡metros'),(69,'modpasarelas/','Permiso para acceder a la activaciÃ³n/desactivaciÃ³n de pasarelas'),(71,'modprofile/','Permiso para acceder al mantenimiento de perfiles'),(72,'modreporting/','Permiso para acceder al mÃ³dulo de reporting'),(73,'modreporting/avanzado','Permiso para poder acceder al mÃ³dulo de reporting en modo avanzado'),(74,'modreporting/boton_mostrarsql','Permiso para poder visualizar el botÃ³n mostrar sql en el mÃ³dulo modreporting'),(75,'modreporting/compartir_listados','Permiso para poder compartir listados en el mÃ³dulo modreporting'),(76,'modreporting_avanzado','Permiso para acceder al reporting avanzado en el mÃ³dulo modreporting'),(81,'modusers/','Permiso para poder acceder al mantenimiento de usuarios'),(82,'modusuarios/','Permiso para acceder al mantenimiento de usuarios'),(83,'modvisorreporting/','Permiso para acceder al listado de informes'),(86,'ventanas_administracion','Permiso para ver la cabecera de administraciÃ³n en el menÃº'),(93,'modregiones/','pantalla de gestion de regiones');
/*!40000 ALTER TABLE `describir_permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id_group` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `group` tinytext NOT NULL,
  `aliasname` varchar(20) NOT NULL,
  `id_profile` int(11) NOT NULL,
  `id_location` int(11) NOT NULL,
  PRIMARY KEY (`id_group`),
  KEY `id_profile` (`id_profile`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (11,'Usuario Consultas','administrador',14,0),(12,'Usuario Administrador','',14,0);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_cambiotablas`
--

DROP TABLE IF EXISTS `log_cambiotablas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_cambiotablas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tabla` varchar(100) NOT NULL,
  `actualizada` datetime NOT NULL,
  `comentario` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_cambiotablas`
--

LOCK TABLES `log_cambiotablas` WRITE;
/*!40000 ALTER TABLE `log_cambiotablas` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_cambiotablas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_permisos`
--

DROP TABLE IF EXISTS `map_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_permisos` (
  `id_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `permiso` varchar(200) NOT NULL,
  PRIMARY KEY (`id_permiso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_permisos`
--

LOCK TABLES `map_permisos` WRITE;
/*!40000 ALTER TABLE `map_permisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_permisos_usuarios`
--

DROP TABLE IF EXISTS `map_permisos_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_permisos_usuarios` (
  `id_permisos_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_permiso` int(11) NOT NULL,
  `habilitado` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_permisos_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_permisos_usuarios`
--

LOCK TABLES `map_permisos_usuarios` WRITE;
/*!40000 ALTER TABLE `map_permisos_usuarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `map_permisos_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiles` (
  `id_profile` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `isgroupprofile` tinyint(4) NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  `id_nodo` int(11) NOT NULL,
  PRIMARY KEY (`id_profile`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` VALUES (14,'Perfil administrador',1,0,9),(86,'Perfil Consultas',0,0,0);
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporting_user_list`
--

DROP TABLE IF EXISTS `reporting_user_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporting_user_list` (
  `id_reporting_user_list` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `id_user` int(11) NOT NULL,
  `columns` text NOT NULL,
  `groupsby` text NOT NULL,
  `subtotals` text NOT NULL,
  `average` text NOT NULL,
  `modosfiltro` text NOT NULL,
  `filter_php_data` text NOT NULL,
  `id_group` int(10) unsigned NOT NULL,
  `eliminado` smallint(5) unsigned NOT NULL DEFAULT '0',
  `acumuladores` text NOT NULL,
  `pendiente` int(11) NOT NULL DEFAULT '0',
  `id_user_envia` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_reporting_user_list`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporting_user_list`
--

LOCK TABLES `reporting_user_list` WRITE;
/*!40000 ALTER TABLE `reporting_user_list` DISABLE KEYS */;
INSERT INTO `reporting_user_list` VALUES (1,'Empleados',0,'D_RESUMEN_DATOS_emp_no,D_RESUMEN_DATOS_first_name,D_RESUMEN_DATOS_title,','','','','{}','a:0:{}',0,0,'',0,0),(2,'Empleados 2',25,'D_RESUMEN_DATOS_emp_no,D_RESUMEN_DATOS_hire_date,D_RESUMEN_DATOS_salary,D_RESUMEN_DATOS_first_name,D_RESUMEN_DATOS_title,','D_RESUMEN_DATOS_emp_no,D_RESUMEN_DATOS_title,D_RESUMEN_DATOS_first_name','','','{}','a:0:{}',0,0,'',0,0),(3,'Salario por cargo',25,'D_RESUMEN_DATOS_first_name,D_RESUMEN_DATOS_title,D_RESUMEN_DATOS_salary,','D_RESUMEN_DATOS_first_name,D_RESUMEN_DATOS_title','','','{\"D_RESUMEN_DATOS_compagnia_del_pedido\": \"igual\",\"D_RESUMEN_DATOS_title\": \"igual\"}','a:2:{i:0;a:2:{s:4:\"tipo\";s:36:\"D_RESUMEN_DATOS_compagnia_del_pedido\";s:6:\"param1\";s:5:\"00001\";}i:1;a:3:{s:4:\"tipo\";s:21:\"D_RESUMEN_DATOS_title\";s:6:\"param0\";s:8:\"Manager \";s:6:\"param1\";s:13:\"Senior Staff \";}}',0,0,'',0,0),(4,'Salarioxcargo',244,'D_RESUMEN_DATOS_first_name,D_RESUMEN_DATOS_title,D_RESUMEN_DATOS_salary,','D_RESUMEN_DATOS_first_name,D_RESUMEN_DATOS_title','','','{\"D_RESUMEN_DATOS_compagnia_del_pedido\": \"igual\",\"D_RESUMEN_DATOS_title\": \"igual\"}','a:2:{i:0;a:2:{s:4:\"tipo\";s:36:\"D_RESUMEN_DATOS_compagnia_del_pedido\";s:6:\"param1\";s:5:\"00001\";}i:1;a:3:{s:4:\"tipo\";s:21:\"D_RESUMEN_DATOS_title\";s:6:\"param0\";s:8:\"Manager \";s:6:\"param1\";s:13:\"Senior Staff \";}}',0,0,'',0,25);
/*!40000 ALTER TABLE `reporting_user_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_param`
--

DROP TABLE IF EXISTS `system_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_param` (
  `id_system_param` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `system_param_title` tinytext NOT NULL,
  `system_param_value` tinytext NOT NULL,
  PRIMARY KEY (`id_system_param`)
) ENGINE=MyISAM AUTO_INCREMENT=219 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_param`
--

LOCK TABLES `system_param` WRITE;
/*!40000 ALTER TABLE `system_param` DISABLE KEYS */;
INSERT INTO `system_param` VALUES (13,'correo_admin','comercial@servicios-dpi.com'),(14,'gw_sourcefiles_path','/var/www/ecomm4_data/adjuntos'),(15,'gw_viewfiles_path','/var/www/ecomm4_data/view'),(16,'hfaxgw_path_avantfax','/var/www/ecomm4_data/logs'),(17,'hfaxgw_ultima_captura','604800'),(18,'labelbasica_es','Areas'),(19,'path_emailadjuntos','/var/www/ecomm4_data/adjuntos/'),(20,'path_store_pdf','/var/www/ecomm4_data/srcpdf'),(21,'zfaxgw_path_logs_zfax','/home/oscar/www/ecomm/logs'),(22,'zfaxgw_ultima_captura','1264073415'),(23,'ultimo_countrydetector','5124'),(24,'id_label_type_countrys','5'),(25,'last_infofaxindex','1'),(26,'id_label_infofax','36'),(27,'id_channel_infofax','13'),(28,'hfax_id_channel_default','7'),(29,'gw_viewfiles_webpath','/ecomm4_data/view'),(30,'label_location_id','7'),(31,'map_labelsshow','32,30,31'),(33,'id_channel_notallamada','8'),(34,'optimize_last_min','19'),(35,'stats_last_hour','11'),(36,'stats_delay','2'),(129,'id_task_siniestros','14'),(130,'id_task_cotizaciones','15'),(41,'core.id_canal_defecto','14'),(131,'label_location_id','7'),(132,'id_tipos_siniestros','9'),(133,'id_tipos_cotizacion','10'),(134,'colas.asignacionautomatica','1'),(135,'colas.usa_idiomas','1'),(136,'colas.usa_idiomas_peso','60'),(137,'colas.usa_delegacion','1'),(138,'colas.usa_delegacion_peso','3'),(139,'colas.usa_controlcarga','1'),(140,'colas.usa_controlcarga_peso','100'),(141,'colas.balanceo','demanda'),(144,'core.id_group_default','1'),(145,'colas.ultimousuarioRR','4'),(146,'core.id_location_default','1'),(147,'core.id_label_type_user','1'),(157,'core.id_user_desconocido','1'),(163,'id_status_enestudio','23'),(172,'noticias.codigo_correo','mikymouse'),(173,'ruta_ges_documental','/var/www/ecomm4_data/upload'),(176,'efax.last_efaxindex','5145'),(177,'efax.id_label_efax','90'),(178,'efax.id_channel_efax','14'),(184,'sinli.pendiente_SINLI','29'),(216,'emailgw_ultima_captura','1378813490');
/*!40000 ALTER TABLE `system_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups` (
  `id_user_groups` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` smallint(5) unsigned NOT NULL,
  `id_group` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_user_groups`),
  KEY `id_user` (`id_user`),
  KEY `id_group` (`id_group`)
) ENGINE=MyISAM AUTO_INCREMENT=865 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES (845,205,16),(279,17,15),(288,77,11),(284,83,12),(280,78,13),(286,79,14),(841,80,45),(223,81,16),(285,82,17),(684,232,55),(230,5,11),(18,67,15),(693,18,11),(725,45,14),(156,87,12),(25,91,5),(653,46,40),(33,84,20),(628,22,35),(672,51,39),(505,48,31),(496,92,27),(827,93,12),(655,72,27),(37,94,12),(665,41,30),(41,95,12),(42,96,12),(163,97,12),(47,98,12),(591,13,20),(49,99,12),(50,74,12),(164,101,12),(56,102,12),(58,103,12),(59,104,12),(165,105,12),(61,106,12),(218,65,20),(63,107,12),(733,108,14),(166,110,12),(66,111,12),(246,112,12),(68,109,12),(836,113,12),(735,114,14),(71,115,12),(168,116,12),(73,117,12),(247,118,12),(75,119,12),(169,120,12),(77,121,12),(170,122,12),(248,123,12),(80,124,12),(81,126,12),(171,125,12),(83,127,12),(172,128,12),(85,129,12),(86,131,12),(739,132,14),(173,133,12),(249,134,12),(91,135,12),(174,136,12),(93,137,12),(721,138,14),(95,139,12),(250,140,12),(750,141,14),(98,142,12),(723,143,14),(100,145,12),(176,146,12),(741,147,14),(252,148,12),(104,149,12),(177,150,12),(106,151,12),(731,152,14),(108,153,12),(745,154,14),(240,155,12),(253,156,12),(717,157,14),(113,158,12),(762,49,34),(254,159,12),(116,160,12),(729,43,14),(118,53,12),(119,161,12),(245,162,12),(121,163,12),(737,42,14),(244,164,12),(125,165,12),(719,44,14),(127,166,12),(128,167,12),(129,169,12),(130,168,12),(255,170,12),(256,171,12),(752,172,12),(257,173,12),(136,174,12),(258,175,12),(716,176,12),(259,177,12),(141,178,12),(261,179,12),(143,180,12),(262,181,12),(263,183,12),(265,184,12),(264,185,12),(266,186,12),(267,187,12),(268,188,12),(269,189,12),(270,190,12),(274,191,12),(727,192,14),(157,193,12),(158,194,12),(241,195,12),(160,196,12),(161,197,12),(162,198,12),(179,199,12),(453,28,45),(181,40,15),(182,12,15),(479,31,43),(489,19,50),(620,37,46),(451,60,42),(470,36,47),(481,30,43),(455,27,45),(447,32,42),(457,70,45),(467,35,47),(459,69,45),(449,33,42),(383,23,15),(485,38,51),(864,244,11),(201,200,15),(202,201,15),(203,202,15),(204,203,15),(299,20,24),(298,66,24),(422,54,25),(287,77,21),(446,32,15),(720,44,28),(217,58,11),(219,14,11),(282,206,16),(228,26,11),(863,25,11),(233,56,11),(832,207,20),(332,208,20),(334,209,20),(336,210,20),(251,144,12),(837,211,24),(289,212,24),(290,212,25),(291,213,24),(631,214,12),(421,54,20),(341,76,26),(627,22,34),(652,46,29),(504,48,33),(671,51,28),(340,76,20),(495,92,20),(831,207,27),(333,208,27),(335,209,27),(337,210,27),(488,19,41),(487,19,51),(486,19,15),(484,38,50),(483,38,41),(482,38,15),(478,31,15),(480,30,15),(450,60,15),(448,33,15),(477,21,49),(476,21,15),(590,13,49),(589,13,46),(588,13,47),(587,13,44),(619,37,47),(469,36,46),(468,36,15),(618,37,15),(466,35,46),(465,35,15),(384,23,53),(776,237,58),(452,28,15),(454,27,15),(456,70,15),(458,69,15),(828,216,16),(770,62,11),(784,238,12),(520,215,20),(503,48,36),(502,48,27),(651,46,20),(650,46,27),(670,51,38),(669,51,27),(668,51,20),(626,22,37),(625,22,27),(624,22,20),(430,63,15),(431,63,49),(501,48,20),(840,80,59),(753,217,15),(586,13,15),(585,13,27),(592,218,15),(593,218,45),(594,219,15),(595,219,47),(596,219,46),(597,219,49),(826,229,11),(617,228,54),(706,227,49),(705,227,46),(704,227,47),(703,227,15),(623,61,24),(654,72,20),(664,41,27),(656,72,30),(663,41,20),(666,230,27),(667,230,20),(673,231,57),(674,231,55),(677,9,11),(683,232,11),(685,232,57),(799,233,55),(798,233,57),(695,234,55),(696,234,57),(697,235,57),(698,235,55),(699,236,55),(700,236,57),(718,157,39),(802,240,57),(722,138,38),(724,143,40),(726,45,29),(728,192,29),(730,43,36),(732,152,33),(734,108,33),(736,114,33),(738,42,35),(740,132,35),(742,147,34),(761,49,14),(746,154,37),(801,204,56),(751,141,37),(783,11,45),(782,11,48),(781,11,15),(785,239,12),(800,204,57),(803,240,56),(823,241,12),(813,242,61),(812,242,59),(839,80,15),(838,211,63),(842,80,63),(846,205,66),(854,243,68),(853,243,67),(852,243,69);
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id_user` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `s_name1` tinytext NOT NULL,
  `s_name2` tinytext NOT NULL,
  `email` tinytext NOT NULL,
  `phone` tinytext NOT NULL,
  `user_login` tinytext NOT NULL,
  `pass_login` tinytext NOT NULL,
  `date_in` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `eac_rights` enum('0','1') NOT NULL DEFAULT '0',
  `id_profile` int(20) NOT NULL,
  `eslogueado` tinyint(4) NOT NULL DEFAULT '0',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  `id_nodo` int(11) NOT NULL DEFAULT '0',
  `avatar` varchar(99) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `delete` (`deleted`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (25,'administrador','administrador','','administrador@organizacion','','admin','admin','2009-04-13 20:00:00','0',0,1,'0',41,'0.gif'),(244,'Juan','Perez','Sanchez','juan.perez@organizacion.com','','Juan','juan','2013-10-28 12:42:03','0',0,0,'0',1,''),(245,'otro','','','','','eliminado_','','2013-10-28 12:42:17','0',0,0,'1',0,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-10-29 13:18:53
